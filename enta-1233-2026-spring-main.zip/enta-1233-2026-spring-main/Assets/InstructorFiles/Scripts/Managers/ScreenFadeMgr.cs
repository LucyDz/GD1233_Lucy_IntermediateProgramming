
/// <summary>
/// UI overlay used for loading between scenes or waiting for something async to resolve
/// </summary>
public class ScreenFadeOverlay : MenuBase
{
}
